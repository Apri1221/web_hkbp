SEMUA FILE YANG ADA DALAM FOLDER INI UTK VERSI PRODUKSI
Lakukan build production dengan:
1. Masuk ke link https://babeljs.io/repl
2. Paste file react js versi jsx
3. Copy pada kolom sebelah kanan
4. Buat file / copas ke file dengan nama yang sama pada versi development
5. Uncomment pada file blade template src babeljs
6. Src file react js pada tiap tiap view diganti dari js menjadi prod/js

Jika dalam fase development, kembalikan src babeljs, gunakan folder asset/js, dan kerjakan pada folder dan file tersebut