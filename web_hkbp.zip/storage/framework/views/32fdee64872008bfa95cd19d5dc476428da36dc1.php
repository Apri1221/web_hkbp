

<?php $__env->startPush('any_css'); ?>
<link rel="stylesheet" href="https://unpkg.com/react-jinke-music-player@4.19.0/assets/index.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div id="contentIbadah" post-id=<?php echo e($id); ?>></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('any_js'); ?>

<!-- https://codepen.io/cwiens/full/gyvqrg, https://greensock.com/cheatsheet/ -->

<script src="https://unpkg.com/react-jinke-music-player@4.19.0/dist/react-jinke-music-player.min.js"></script>

<script type="text/babel" src="<?php echo e(asset('assets/js/dataIbadah.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Apriyanto JPL Tobing\Documents\MyRepo\web_hkbp\resources\views/ibadah.blade.php ENDPATH**/ ?>