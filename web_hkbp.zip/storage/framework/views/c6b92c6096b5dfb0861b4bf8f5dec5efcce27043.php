<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600" rel="stylesheet">

    <!-- Semantic CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css">

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

    <script src="https://unpkg.com/babel-standalone@6/babel.min.js"></script>
    <!-- react js -->
    <script crossorigin src="https://unpkg.com/react@16/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@16/umd/react-dom.production.min.js"></script>

    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #fff;
            color: #414141;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .ui.parallax {
            height: 30em;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
        }

        .ui.fluid.parallax {
            width: 100%;
        }

        .ui.secondary.pointing.menu {
            background-color: white;
        }

        #sticky-header {
            position: -webkit-sticky;
            position: sticky;
            top: 0;
            z-index: 999;
            margin: 0;
        }

        @media  only screen and (min-width: 720px) {
            #sticky-content {
                position: -webkit-sticky;
                position: sticky;
                top: 6rem;
            }
        }

        .icon-mentor>img {
            vertical-align: middle;
            height: 60px !important;
            margin: 10px
        }

        .box {
            -webkit-box-shadow: 0 10px 10px rgba(0, 0, 0, .03);
            -moz-box-shadow: 0 10px 10px rgba(0, 0, 0, .03);
            box-shadow: 0 10px 10px rgba(0, 0, 0, .03);
            transition: all .2s ease-in-out 0s
        }

        @media  screen and (min-width:580px) {
            .box:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 15px rgba(0, 0, 0, .11), 0 5px 8px rgba(105, 105, 105, .2)
            }
        }
    </style>
</head>

<body>
    <div class="ui fluid parallax" data-imgsrc="<?php echo e(asset('./assets/images/curch.jpg')); ?>"></div>

    <div>
        <div class="ui huge menu" id='sticky-header'>
            <div class="ui container">
                <div class="header item">
                    <img style="width: 20px;" src="<?php echo e(asset('./assets/images/HKBP_40.jpg')); ?>">
                </div>
                <div class="right menu">
                    <div class="item">
                        <?php if(Session::has('account')): ?>
                            <a class="ui primary button" href="<?php echo e(route('logout')); ?>">Keluar</a>
                        <?php else: ?>
                            <div class="ui primary button" id="btnModal">Masuk</div>
                        <?php endif; ?>
                    </div>
                    <a class="item">Pengembang</a>
                </div>
            </div>
        </div>

        <div class="ui tiny modal">
            <i class="close icon"></i>
            <div class="header">
                Title
            </div>
            <div class="content">
                <?php if(Session::has('gagal')): ?>
                <div class="ui icon warning message">
                    <i class="lock icon"></i>
                    <div class="content">
                        <div class="header">
                            Gagal Masuk!
                        </div>
                        <p>Alamat email atau kata sandi mungkin salah!</p>
                    </div>
                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="ui form">
                        <div class="inline fields">
                            <div class="sixteen wide field">
                                <label>Alamat Email</label>
                                <input name="email" type="email" placeholder="Email">
                            </div>
                        </div>
                        <div class="inline fields">
                            <div class="sixteen wide field">
                                <label>Kata Sandi</label>
                                <input name="password" type="password" placeholder="Kata Sandi">
                            </div>
                        </div>
                    </div>
                    <button class="ui primary labeled icon button" type="submit">
                        <i class="unlock alternate icon"></i>
                        Login
                    </button>
                </form>
            </div>
        </div>


        <div class="ui container" style="margin:70px 0">
            <div class="ui stackable grid" style="align-items: flex-start;">
                <div class="column">
                    <div id="table" type-user="<?php echo e(Session::has('account') ? 'admin' : 'user'); ?>" style="overflow-x:auto;"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Semantic JS -->
    <script src="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.js"></script>
    <script src="<?php echo e(asset('./assets/lib/tablesort/tablesort.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $.fn.uiParallax = function() {
                $(this).each(function() {
                    var imageUrl = $(this).data('imgsrc');
                    $(this).css('background-image', 'url(' + imageUrl + ')');
                });
            };

            // user's code to initialise parallaxes
            $('.ui.parallax').uiParallax();
            $('#btnModal').click(function() {
                $('.ui.tiny.modal').modal('show');
            })
        });
    </script>


    <script type="text/babel" src="<?php echo e(asset('assets/js/searchData.js')); ?>"></script>

</body>

</html><?php /**PATH C:\Users\Apriyanto JPL Tobing\Documents\MyRepo\HKBP\web_hkbp\resources\views\welcome.blade.php ENDPATH**/ ?>