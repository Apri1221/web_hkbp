const TableBody = props => {
    if (props.header.length == 0) {
        return (
            <div className="ui fluid placeholder">
                <div className="very short line"></div>
                <div className="paragraph">
                    <div className="line"></div>
                    <div className="line"></div>
                    <div className="line"></div>
                </div>
                <div className="very short line"></div>
                <div className="paragraph">
                    <div className="line"></div>
                    <div className="line"></div>
                    <div className="line"></div>
                </div>
            </div>
        )
    }
    return (
        <div id="tableJemaat">
            <table className="ui single line selectable sortable striped unstackable definition table">
                <thead>
                    <tr>
                        {
                            props.header.map((item, key) =>
                                <th className="sorted ascending" key={key}>{item}</th>)
                        }
                    </tr>
                </thead>
                <tbody>
                    {
                        props.filteredData.map(item => ( // given an object
                            <tr key={item}>
                                {/* we want to get the each paired value-key in obj */}
                                {Object.keys(item).map(key =>
                                    <td key={key}>{item[key]}</td>)}
                            </tr>
                        ))
                    }
                </tbody>
            </table>
        </div>
    )
}


class App extends React.Component {
    constructor() {
        super();
        this.state = {
            sektor: "",
            filter: "",
            data: [],
            header: [],
            urls: []
        };
    }

    componentDidMount() {
        $('#dropdown-sektor').dropdown({ clearable: true });
        const urlFetch = fetch('http://localhost:8000/api/list');
        urlFetch.then(result => {
            if (result.status === 200)
                return result.json()
        }).then(resJson => {
            Object.keys(resJson).map((item, key) => {
                this.state.urls.push(resJson[item])
            })
            this.setState(() => { // re-render
                return { unseen: "does not display" }
            });
        })
    }

    handleChange = event => {
        console.log(event.target.value)
        this.setState({ filter: event.target.value });
        console.log(this.state.sektor)
    };

    handleSektor = event => {
        let type_user = $('#table').attr("type-user"); //get the data attribute variable
        // check search history
        if (event.target.value == '' || event.target.value == this.state.sektor) {
            return;
        }
        this.setState({ // assign search history
            sektor: event.target.value,
            data: [],
            header: [],
        })
        const urlFetch = fetch('http://localhost:8000/api/data/' + event.target.value + '/default/' + type_user);
        urlFetch.then(result => {
            if (result.status === 200)
                return result.json()
        }).then(resJson => {
            Object.keys(resJson).map((item, key) => {
                var data = resJson[item];
                var header = Object.keys(data);
                if (this.state.header.length == 0) {
                    this.state.header.push(header);
                }
                this.state.data.push(data);
            })

            this.setState(() => { // re-render (must)
                return { unseen: "does not display" }
            });
            $('table').tablesort() // sort with tablesort js and semantic
        })
    };

    render() {
        const { filter, data, urls, sektor } = this.state;
        const lowercasedFilter = filter.toLowerCase(); // what user typing
        var filteredData = data.filter(item => {
            return Object.keys(item).some(key =>
                item[key].toLowerCase().includes(lowercasedFilter)
            );
        });

        var header = this.state.header; // data before fetch
        if (header[0]) {
            header = header[0]; // if data already fetch
        }
        console.log(data)

        return (
            <div className="">
                <div className="ui huge form">
                    <div className="inline fields">
                        <div className="field">
                            <div className="ui left icon input">
                                <input value={filter} onChange={this.handleChange} type="text" placeholder="Cari Jemaat" />
                                <i className="users icon"></i>
                            </div>
                        </div>
                        <div className="field">
                            <select id="dropdown-sektor" className="ui search dropdown" onChange={this.handleSektor}>
                                <option value="">Pilih Sektor</option>
                                {
                                    urls.map(item => ( // given an object
                                        <option value={item["sektor"]}>{item["sektor"]}</option>
                                    ))
                                }
                            </select>
                        </div>
                    </div>
                </div>
                {sektor ? <TableBody filteredData={filteredData} header={header} /> : ''}

            </div>
        );

    }
}

$(document).ready(function () {
    ReactDOM.render(<App />, document.getElementById("table"));
});