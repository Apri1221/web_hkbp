@extends('layouts.template')
@push('any_css')
<style>
    #detailKeluarga {
        background-position: center;
        /* di dribble, dapat gunakn query compress=1&resize=400x300 utk mereduksi file gambar */
        background-image: url("https://cdn.dribbble.com/users/507883/screenshots/3717340/andy-hau-mountains-sunset-illustration.jpg?compress=1&resize=400x300");
        object-fit: cover;
        color: brown
    }

    body #title-massive {
        font-family: 'Montserrat', sans-serif;
        color: white
    }

    .ui.custom.header {
        font-size: 4rem !important;
    }
    .ui.form .inline.fields .field {
        padding: 0 1em 1em 0 !important
    }
</style>
@endpush

@push('any_content')
<div class="ui fluid parallax" data-imgsrc="{{ asset('./assets/images/curch.jpg') }}">
    <div class="ui container" style="padding:60vh 0 0">
        <div class="ui two column stackable grid">
            <div class="column">
                <div class="ui custom left aligned header" id="title-massive">
                    We Worship You
                </div>
            </div>
            <div class="column">
                <!-- Not yet content -->
            </div>
        </div>
    </div>
</div>
@endpush

@section('content')
<div class="ui container" style="margin:70px 0">
    <div class="ui stackable grid" style="align-items: flex-start;">
        <div class="column">
            <div id="table" type-user="{{ Session::has('account') ? 'admin' : 'user' }}"></div>
        </div>
    </div>

    <!-- modal ini digunakan untuk menampilkan data keluarga dari searchData.js (ini sangat kompleks) -->
    <div class="ui tiny modal" id="modalDataKeluarga">
        <div class="huge header" id="detailKeluarga">
        </div>
        <div class="content ui left aligned container" id="dataKeluarga">
        </div>
    </div>
</div>
@endsection

@push('any_js')
<script type="text/babel" src="{{ asset('assets/js/searchData.js') }}"></script>
@endpush