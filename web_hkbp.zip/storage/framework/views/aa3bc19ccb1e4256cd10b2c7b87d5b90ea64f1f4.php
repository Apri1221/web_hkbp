<?php $__env->startPush('any_css'); ?>
<style>
    #detailKeluarga {
        background-position: center;
        /* di dribble, dapat gunakn query compress=1&resize=400x300 utk mereduksi file gambar */
        background-image: url("https://cdn.dribbble.com/users/507883/screenshots/3717340/andy-hau-mountains-sunset-illustration.jpg?compress=1&resize=400x300");
        object-fit: cover;
        color: brown
    }

    body #title-massive {
        font-family: 'Montserrat', sans-serif;
        color: white
    }

    .ui.custom.header {
        font-size: 4rem !important;
    }

    .ui.form .inline.fields .field {
        padding: 0 1em 1em 0 !important
    }

    .section.blue {
        background-color: var(--main-color-palete)
    }

    .slider .content-custom {
        background: #fff;
        color: #3498db;
        font-size: 36px;
        line-height: 100px;
        margin: 10px;
        padding: 1rem;
        text-align: center;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('top_content'); ?>
<div class="ui fluid parallax" data-imgsrc="<?php echo e(asset('./assets/images/curch.jpg')); ?>">
    <div class="ui container" style="padding:60vh 0 0">
        <div class="ui two column stackable grid">
            <div class="column">
                <div class="ui custom left aligned header" id="title-massive">
                    We Worship You
                </div>
            </div>
            <div class="column">
                <!-- Not yet content -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- modal ini digunakan untuk menampilkan data keluarga dari searchData.js (ini sangat kompleks) -->
<div class="ui tiny modal" id="modalDataKeluarga">
    <div class="header" id="detailKeluarga">
    </div>
    <div class="content ui left aligned container" id="dataKeluarga">
    </div>
</div>

<div class="ui container" style="margin:70px 0">
    <div class="ui stackable grid" style="align-items: flex-start;">
        <!-- section content -->
        <div class="twelve wide column">
            <div id="contentJemaat" type-user="<?php echo e(Session::has('account') ? 'admin' : 'user'); ?>"></div>
            <div class="ui hidden divider huge"></div>
            <div id="announcement"></div>
        </div>
        <!-- section announcement -->
        <div class="four wide column" id="sticky-content">
            <?php $__currentLoopData = $ibadahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ibadah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ui fluid card">
                    <div class="content">
                        <div class="header"><?php echo e($ibadah->title); ?></div>
                    </div>
                    <div class="content">
                        <p class="ui sub header"><?php echo e($ibadah->description); ?></p>
                        <br>
                        <a class="ui primary fluid button" href="/post/<?php echo e($ibadah->id); ?>" rel="noopener noreferrer"></i>Lihat</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <a class="fluid ui positive labeled icon button" href="admin/dashboard#/dataTingting">
                <i class="edit icon"></i>
                Tambah Pelayanan
            </a> -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->yieldPushContent('carousel_js'); ?>
<?php echo $__env->yieldPushContent('tablesort_js'); ?>

<?php $__env->startPush('any_js'); ?>
<script>
    $(document).ready(() => {
        $.fn.uiParallax = function() {
            $(this).each(function() {
                var imageUrl = $(this).data('imgsrc');
                $(this).css('background-image', 'url(' + imageUrl + ')');
            });
        };
        $('.ui.parallax').uiParallax();
    });
</script>

<!-- Library Carousel Slick -->
<script src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

<!-- Library for table sorting -->
<script src="<?php echo e(asset('./assets/lib/tablesort/tablesort.min.js')); ?>"></script>

<script type="text/babel" src="<?php echo e(asset('assets/js/searchData.js')); ?>"></script>
<script type="text/babel" src="<?php echo e(asset('assets/js/announce.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Apriyanto JPL Tobing\Documents\MyRepo\HKBP\web_hkbp\resources\views/welcome.blade.php ENDPATH**/ ?>