<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IbadahController extends Controller
{
    public function getIbadah($id) {
        return view('ibadah', ['id' => $id]);
    }
}
