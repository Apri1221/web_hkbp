<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600" rel="stylesheet">

    <!-- Semantic CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui-react/0.88.2/semantic-ui-react.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css">

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

    <!-- Styles -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@900&display=swap');

        :root {
            --main-box-shadow:
                0 2.1px 2.7px rgb(0, 0, 0, 0.022),
                0 5.2px 6.9px rgb(0, 0, 0, 0.031),
                0 10.6px 14.2px rgb(0, 0, 0, 0.039),
                0 21.9px 29.2px rgb(0, 0, 0, 0.048),
                0 60px 80px rgb(0, 0, 0, 0.07);

            --small-box-shadow:
                0 7.4px 4.1px rgba(0, 0, 0, 0.018),
                0 20px 68px rgba(0, 0, 0, 0.07);


            --main-color-palete: #00a6fb;
            --main-color-palete-dark: #006494;
            /* pink */
            --secondary-color-palete: #ef8354;
            --third-color-palete: #ef8354;
        }

        html,
        body {
            background-color: #fff;
            color: #414141;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .huge.header {
            font-size: 2em !important;
        }

        .ui.button,
        .ui.primary.button {
            box-shadow: var(--main-box-shadow) !important
        }

        .full-height {
            height: 100vh;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .ui.parallax {
            height: 90vh;
            background-attachment: fixed;
            background-position: center;
            background-repeat: no-repeat;
        }

        .ui.fluid.parallax {
            width: 100%;
        }

        .ui.secondary.pointing.menu {
            background-color: white;
        }

        #sticky-header {
            position: -webkit-sticky;
            position: sticky;
            top: 0;
            z-index: 1
                /* this is max of z-index using semantics! */
            ;
            margin: 0;
        }

        @media only screen and (min-width: 720px) {
            #sticky-content {
                position: -webkit-sticky;
                position: sticky;
                top: 6rem;
            }
        }

        .icon-mentor>img {
            vertical-align: middle;
            height: 60px !important;
            margin: 10px
        }

        .raised-shadow {
            box-shadow: var(--small-box-shadow)
        }

        #tableJemaat {
            overflow-x: auto;
        }
    </style>
    @stack('any_css')

</head>

<body>
    @stack('any_content')

    <div>
        <div class="ui huge menu" id='sticky-header'>
            <div class="ui container">
                <div class="header item">
                    <a href="{{ route('home') }}">
                        <img style="width: 20px;" src="{{ asset('./assets/images/HKBP_40.jpg') }}"></a>
                </div>
                <div class="right menu">
                    <div class="item">
                        @if(Session::has('account'))
                        <a class="ui primary button" href="{{ route('logout') }}">Keluar</a>
                        @else
                        <div class="ui primary button" id="btnModal">Masuk</div>
                        @endif
                    </div>
                    <div class="ui floating dropdown item" id="dropdown-menu">Menu<i class="dropdown icon"></i>
                        <div class="menu">
                            <a class="item">
                                <i class="user secret icon"></i>Pengembang
                            </a>

                            <a class="item" href="{{ route('dashboard') }}">
                                <i class="th icon"></i>Dashboard
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="ui tiny modal" id="account">
            <i class="close icon"></i>
            <div class="header">
                Silakan Masuk
            </div>
            <div class="content ui left aligned container">
                @if(Session::has('gagal'))
                <div class="ui icon warning message">
                    <i class="lock icon"></i>
                    <div class="content">
                        <div class="header">
                            Gagal Masuk!
                        </div>
                        <p>Alamat email atau kata sandi mungkin salah!</p>
                    </div>
                </div>
                @endif

                <form action="{{ route('login') }}" method="POST">
                    @csrf
                    <div class="ui form">
                        <div class="field">
                            <label>Alamat Email</label>
                            <input name="email" type="email" placeholder="Email">
                        </div>
                        <div class="field">
                            <label>Kata Sandi</label>
                            <input name="password" type="password" placeholder="Kata Sandi">
                        </div>
                        <button class="ui primary labeled icon button" type="submit">
                            <i class="unlock alternate icon"></i>
                            Login
                        </button>
                    </div>
                </form>
            </div>
        </div>

        @yield('content')

    </div>

    <script src="https://unpkg.com/babel-standalone@6/babel.min.js"></script>

    <!-- react js v16 -->
    <script src="{{ asset('./assets/lib/react/react-production.min.js') }}"></script>
    <script src="{{ asset('./assets/lib/react/reactdom-production.min.js') }}"></script>

    <!-- Semantic JS -->
    <script src="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.js"></script>
    <script src="{{ asset('./assets/lib/tablesort/tablesort.min.js') }}"></script>

    <script>
        $(document).ready(function() {
            $('.menu .item').tab();

            $.fn.uiParallax = function() {
                $(this).each(function() {
                    var imageUrl = $(this).data('imgsrc');
                    $(this).css('background-image', 'url(' + imageUrl + ')');
                });
            };

            $('.ui.parallax').uiParallax();

            $('#dropdown-menu').dropdown();

            $('#btnModal').click(function() {
                $('#account').modal('show');
            })
        });
    </script>

    @stack('any_js')

</body>

</html>