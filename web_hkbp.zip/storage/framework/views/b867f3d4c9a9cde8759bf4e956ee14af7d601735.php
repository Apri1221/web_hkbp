

<?php $__env->startSection('content'); ?>
<div class="ui container" style="margin:70px 0">
    <div id="contentIbadah" post-id=<?php echo e($id); ?> ></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('any_js'); ?>

<!-- https://codepen.io/cwiens/full/gyvqrg, https://greensock.com/cheatsheet/ -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.3.0/gsap.min.js"></script>

<script type="text/babel" src="<?php echo e(asset('assets/js/dataIbadah.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Apriyanto JPL Tobing\Documents\MyRepo\HKBP\web_hkbp\resources\views/post.blade.php ENDPATH**/ ?>