Library used in this App is:
JQUERY : jquery-3.5.1.min.js
SEMANTIC UI : semantic-ui@2.4.2
REACT : react & reactDOM v16
TABLE SORT
GREENSOCK GSAP : gsap/3.3.0/gsap.min.js