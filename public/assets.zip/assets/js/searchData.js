const TableBody = props => {
    if (props.header.length == 0) {
        return (
            <div className="ui fluid placeholder">
                <div className="very short line"></div>
                <div className="paragraph">
                    <div className="line"></div>
                    <div className="line"></div>
                    <div className="line"></div>
                </div>
                <div className="very short line"></div>
                <div className="paragraph">
                    <div className="line"></div>
                    <div className="line"></div>
                    <div className="line"></div>
                </div>
            </div>
        )
    }
    return (
        <div id="tableJemaat" className="raised-shadow">
            <table className="ui single line selectable sortable striped unstackable table">
                <thead>
                    <tr>
                        {
                            props.header.map((item, key) => {
                                if (item != 'Kode Keluarga') {
                                    return <th className="sorted ascending" key={key}>{item}</th>
                                }
                            })
                        }
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        props.filteredData.map(item => ( // given an object
                            <tr key={item}>
                                { /* we want to get the each paired value-key in obj */
                                    Object.keys(item).map(key => {
                                        if (key != 'Kode Keluarga') {
                                            return <td key={key}>{item[key]}</td>
                                        }
                                    })
                                }
                                {
                                    <td>
                                        <button onClick={props.whenClicked.bind(null, item['Kode Keluarga'], props.sektor)}
                                            className="ui inverted blue button btnModal"><i className="child icon"></i>Anggota Keluarga</button>
                                    </td>
                                }
                            </tr>
                        ))
                    }
                </tbody>
            </table>
        </div>
    )
}

class App extends React.Component {
    constructor() {
        super();
        this.state = {
            sektor: "",
            filter: "",
            data: [],
            header: [],
            urls: []
        };
        this.handleSearch = this.handleSearch.bind(this)
    }

    componentDidMount() {
        $('#dropdown-sektor').dropdown({ clearable: true });
        const urlFetch = fetch('http://localhost:8000/api/list');
        urlFetch.then(result => {
            if (result.status === 200)
                return result.json()
        }).then(resJson => {
            Object.keys(resJson).map((item, key) => {
                this.state.urls.push(resJson[item])
            })
            this.setState(() => { // re-render
                return { unseen: "does not display" }
            });
        })
    }

    handleKeluagaJemaat(kodeKeluarga, sektor) {
        fetch('http://localhost:8000/api/data/' + sektor + '/user?familyID=' + kodeKeluarga)
        .then(res => res.json())
        .then(resJson => {
            const data = Object.keys(resJson).map((item, key) => {
                return resJson[item];
            })
            // ini mulai setelah data sektor telah ada
            const formTarget = '#dataKeluarga';
            $('#detailKeluarga').html('');
            $('#detailKeluarga').append('Keluarga ' + data[0]['Nama']);
            $(formTarget).html('');
            data.forEach(item => {
                $(formTarget).append('<div class="ui list"><div class="item"><div class="header">' + item['Nama'] + '</div>' + item['Hubungan'] + '</div></div>');
            });
            
            // nama modalnya
            $('#modalDataKeluarga').modal({
                inverted: true
            }).modal('show');
        })
    }

    handleSearch = event => {
        this.setState({ filter: event.target.value });
    };

    handleSektor = event => {
        let type_user = $('#table').attr("type-user"); //get the data attribute variable
        // check search history
        const sektor = event.target.value;
        if (sektor == '' || sektor == this.state.sektor) {
            return;
        }

        const urlFetch = fetch('http://localhost:8000/api/data/' + event.target.value + '/' + type_user + '?relation=Kepala Keluarga');
        urlFetch.then(result => {
            if (result.status === 200)
                return result.json()
        }).then(resJson => {
            const data = Object.keys(resJson).map((item, key) => {
                return resJson[item];
            })
            const header = Object.keys(resJson[0]).map(key => key);

            this.setState({ // re render
                sektor: sektor,
                data: data,
                header: header,
            })
            $('table').tablesort() // sort with tablesort js and semantic
        })
    };

    render() {
        const { filter, data, header, urls, sektor } = this.state;
        const lowercasedFilter = filter.toLowerCase(); // what user typing
        var filteredData = data.filter(item => {
            return Object.keys(item).some(key =>
                item[key].toLowerCase().includes(lowercasedFilter)
            );
        });

        return (
            <div className="">
                <div className="ui big form">
                    <div className="inline fields">
                        <div className="field">
                            <div className="ui left icon input">
                                {/* Correct: handleClick is passed as a reference! */}
                                <input value={filter} onChange={this.handleSearch} type="text" placeholder="Cari Jemaat" />
                                <i className="users icon"></i>
                            </div>
                        </div>
                        <div className="field">
                            <select id="dropdown-sektor" className="ui simple search dropdown" onChange={this.handleSektor}>
                                <option value="">Pilih Sektor</option>
                                {
                                    urls.map(item => ( // given an object
                                        <option value={item["sektor"]}>{item["sektor"]}</option>
                                    ))
                                }
                            </select>
                        </div>
                    </div>
                </div>
                {sektor ? <TableBody filteredData={filteredData} header={header} whenClicked={this.handleKeluagaJemaat} sektor={sektor} /> : ''}
            </div>
        );
    }
}

$(document).ready(function () {
    ReactDOM.render(<App />, document.getElementById("table"));
});